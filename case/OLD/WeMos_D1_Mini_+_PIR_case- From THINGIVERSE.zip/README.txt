                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2489968
WeMos D1 Mini + PIR case by imstrng is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A casing for your WeMos D1 Mini and a HC-SR501 Infrared PIR Motion Sensor.
The WeMos_D1_Mini_HC-SR501_433Mhz_Transmitter is 9mm longer so it can house a 433MHz transmitter.

The WeMos  D1 Mini uses the PIR to detect motion and sends a message over my MQTT broker I run. At the same time the WeMos is capable of receiving instructions from MQTT to switch on the lights in my room by transmitting the KlikAanKlikUit protocol over 433MHz.
This way can place my casings strategically and control the lights.
With the combination of MQTT and Node Red, the possibilities are endless!

I love to see your version of this casing !

# Print Settings

Printer: HyperCube
Rafts: No
Supports: No